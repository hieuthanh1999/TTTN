﻿<?php
	$tenmaychu="localhost";
	$tentaikhoan="root";
	$pass="";
	$csdl="shoe";
	$site_url = 'http://localhost:8080/shoe/';
	$site_admin = 'http://localhost:8080/shoe/admin/';
	$conn=mysqli_connect($tenmaychu, $tentaikhoan, $pass, $csdl) or die("Không kết nối được");
	mysqli_set_charset($conn,"utf8");
?>