For example plugins check https://docs.ckeditor.com/ckfinder/ckfinder3/#!/guide/dev_plugins
